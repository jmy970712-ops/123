// Netlify Function (서버리스): 브라우저가 아니라 이 서버 코드 안에서만 Anthropic API 키를 사용합니다.
// 프론트엔드(index.html)는 이 함수의 주소(/api/generate-followup)만 호출하고,
// 실제 API 키는 Netlify 사이트 설정의 환경변수(ANTHROPIC_API_KEY)에만 존재합니다.

export default async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "content-type": "application/json" },
    });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return new Response(
      JSON.stringify({
        error: "server_not_configured",
        message: "ANTHROPIC_API_KEY가 Netlify 환경변수에 설정되어 있지 않습니다.",
      }),
      { status: 500, headers: { "content-type": "application/json" } }
    );
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "invalid_request" }), {
      status: 400,
      headers: { "content-type": "application/json" },
    });
  }

  const name = typeof body?.name === "string" ? body.name.slice(0, 100) : "";
  const company = typeof body?.company === "string" ? body.company.slice(0, 150) : "";
  const memo = typeof body?.memo === "string" ? body.memo.slice(0, 1500) : "";
  const interests = typeof body?.interests === "string" ? body.interests.slice(0, 200) : "";
  const characteristics = typeof body?.characteristics === "string" ? body.characteristics.slice(0, 300) : "";
  const importance = typeof body?.importance === "string" ? body.importance.slice(0, 5) : "";
  const lang = body?.lang === "ja" ? "ja" : "ko";

  if (!name.trim()) {
    return new Response(JSON.stringify({ error: "missing_name" }), {
      status: 400,
      headers: { "content-type": "application/json" },
    });
  }

  const langLabel = lang === "ja" ? "Japanese (日本語)" : "Korean (한국어)";
  const importanceNote =
    importance === "S"
      ? "This is a very high-priority contact — the tone can be a bit warmer/more eager."
      : importance === "C"
      ? "This is a lower-priority, casual contact — keep the tone light and brief."
      : "";

  const promptParts = [
    `Person's name: ${name}`,
    company ? `Company/role: ${company}` : "",
    memo ? `Notes from the meeting: ${memo}` : "",
    interests ? `Their interests: ${interests}` : "",
    characteristics ? `Impression of them: ${characteristics}` : "",
    importanceNote,
  ].filter(Boolean);

  const userPrompt =
    `You are helping someone write a short, warm follow-up message to a person they recently met through networking. ` +
    `Write ONLY the message text itself in ${langLabel} — no preamble, no explanation, no quotation marks around it. ` +
    `2-4 natural sentences. Reference something specific from the notes/interests if available, but don't sound like a template. ` +
    `Do not invent facts that weren't given.\n\n` +
    promptParts.join("\n");

  try {
    const aiRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 300,
        messages: [{ role: "user", content: userPrompt }],
      }),
    });

    if (!aiRes.ok) {
      const detail = await aiRes.text().catch(() => "");
      return new Response(
        JSON.stringify({ error: "ai_request_failed", status: aiRes.status, detail }),
        { status: 502, headers: { "content-type": "application/json" } }
      );
    }

    const data = await aiRes.json();
    const text = (data?.content || [])
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("")
      .trim();

    if (!text) {
      return new Response(JSON.stringify({ error: "empty_response" }), {
        status: 502,
        headers: { "content-type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ message: text }), {
      status: 200,
      headers: { "content-type": "application/json" },
    });
  } catch (e) {
    return new Response(
      JSON.stringify({ error: "server_error", detail: String(e && e.message ? e.message : e) }),
      { status: 500, headers: { "content-type": "application/json" } }
    );
  }
};

export const config = { path: "/api/generate-followup" };
